import tkinter as tk
import random
import os
import pygame  # Pour le son
from tkinter import messagebox  # Import de messagebox pour la boîte de dialogue

# 📂 Obtenir le dossier où se trouve le script (qui est maintenant dans "assets/")
base_dir = os.path.dirname(os.path.abspath(__file__))
image_path = os.path.join(base_dir, "skibidi.png")
sound_path = os.path.join(base_dir, "jumpscare.mp3")

# 🎵 Initialiser pygame pour le son
pygame.mixer.init()

# 🛑 Fonction pour jouer le son
def play_sound():
    if os.path.exists(sound_path):
        pygame.mixer.music.load(sound_path)
        pygame.mixer.music.play()
    else:
        print(f"❌ Erreur : Impossible de trouver le son à {sound_path}")

# 🖼️ Création de la fenêtre principale
root = tk.Tk()

# 📷 Charger l'image avec gestion d'erreur
try:
    image = tk.PhotoImage(file=image_path)
    image_width, image_height = image.width(), image.height()
except Exception as e:
    print(f"❌ Erreur de chargement de l'image : {e}")
    root.destroy()
    exit()

# 📏 Mettre la fenêtre à la taille de l'image
window_width = image_width
window_height = image_height
root.geometry(f"{window_width}x{window_height}")

# ❌ Supprimer la barre de titre et les bordures
root.overrideredirect(True)

# 📌 Affichage de l'image
label = tk.Label(root, image=image)
label.pack()

# 🏃‍♂️ Fonction pour téléporter la fenêtre aléatoirement
def teleport_window():
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    
    x = random.randint(0, screen_width - window_width)
    y = random.randint(0, screen_height - window_height)
    
    root.geometry(f"{window_width}x{window_height}+{x}+{y}")
    
    root.after(25, teleport_window)  # Refaire toutes les 300ms

# 🎵 Jouer le son immédiatement au lancement
play_sound()

# 🕹️ Lancer l'effet de téléportation
root.after(25, teleport_window)

# 🛑 Fonction pour afficher le message d'erreur après 10 secondes
def show_error():
    # Afficher le message d'erreur avant de fermer la fenêtre
    messagebox.showerror("Erreur", "Re-open the game")
    # Fermer la fenêtre après que le message soit visible
    root.quit()

# Afficher l'erreur après 10 secondes
root.after(3000, show_error)

# 🚀 Lancer l'interface Tkinter
root.mainloop()

