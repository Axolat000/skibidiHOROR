import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess
import sys
import time
import pyttsx3  # Pour la voix robotique de Windows

# Fonction pour tirer la chasse (perd le jeu)
def tirer_la_chasse():
    with open("game_save.txt", "w") as save_file:
        save_file.write("Chasse tirée\n")
    
    root.quit()
    subprocess.Popen([sys.executable, "assets/jumpscare.py"])

# Vérification de la sauvegarde au démarrage
def verifier_sauvegarde():
    try:
        with open("game_save.txt", "r") as save_file:
            save_content = save_file.read().strip()
            
            if save_content == "Skibidi rejoint":
                # Si le joueur a déjà rejoint Skibidi, lancer immédiatement le BAD ENDING
                subprocess.Popen([sys.executable, "assets/BAD ENDING.py"])
                sys.exit(0)  # Quitte le programme principal après avoir lancé le bad ending
            
            elif save_content == "Chasse tirée":
                afficher_texte_et_compte_a_rebours()
            elif save_content == "Recopiage réussi":
                afficher_choix_rejoindre_skibidi()
            else:
                afficher_ecran_normal()
    except FileNotFoundError:
        afficher_ecran_normal()

# Menu principal avec l’image des toilettes
def afficher_ecran_normal():
    global root
    root = tk.Tk()
    root.title("Toilet Game")

    title_label = tk.Label(root, text="Tire la chasse", font=("Arial", 24))
    title_label.pack(pady=20)

    try:
        original_image = Image.open("assets/toilet.png")
        resized_image = original_image.resize((300, 450))
        toilet_image_resized = ImageTk.PhotoImage(resized_image)
    except FileNotFoundError:
        print("L'image 'toilet.png' est introuvable.")
        sys.exit(1)

    toilet_button = tk.Button(root, image=toilet_image_resized, command=tirer_la_chasse, bd=0)
    toilet_button.image = toilet_image_resized  # Évite un problème d'affichage
    toilet_button.pack(pady=20)

    root.mainloop()

# Défi de recopiage avec chrono
def afficher_texte_et_compte_a_rebours():
    global root
    root = tk.Tk()
    root.title("Skibidi Challenge")

    try:
        skibidi_image = Image.open("assets/skibidi.png").resize((300, 450))
        skibidi_image_tk = ImageTk.PhotoImage(skibidi_image)
    except FileNotFoundError:
        print("L'image 'skibidi.png' est introuvable.")
        sys.exit(1)

    skibidi_label = tk.Label(root, image=skibidi_image_tk)
    skibidi_label.pack(pady=20)

    texte_a_recopier = "skibidobdobdoby"
    texte_label = tk.Label(root, text=texte_a_recopier, font=("Arial", 20))
    texte_label.pack(pady=20)

    engine = pyttsx3.init()
    engine.say(texte_a_recopier)
    engine.runAndWait()

    time_left = 10
    chrono_label = tk.Label(root, text=f"Temps restant: {time_left} secondes", font=("Arial", 16))
    chrono_label.pack()

    def update_chrono():
        nonlocal time_left
        if time_left > 0:
            time_left -= 1
            chrono_label.config(text=f"Temps restant: {time_left} secondes")
            root.after(1000, update_chrono)
        else:
            verifier_texte()

    update_chrono()

    entry = tk.Entry(root, font=("Arial", 20))
    entry.pack(pady=20)

    def verifier_texte():
        if entry.get().strip() == texte_a_recopier:
            with open("game_save.txt", "w") as save_file:
                save_file.write("Recopiage réussi\n")
            messagebox.showinfo("Succès", "RE OPEN THE GAME")
        else:
            messagebox.showerror("Erreur", "Vous n'avez pas recopié le texte correctement.")
            subprocess.Popen([sys.executable, "assets/jumpscare.py"])
        
        root.quit()

    root.mainloop()

# Écran où Skibidi demande si on veut le rejoindre
def afficher_choix_rejoindre_skibidi():
    global root
    root = tk.Tk()
    root.title("Rejoindre Skibidi ?")

    try:
        skibidi_image = Image.open("assets/skibidi.png").resize((300, 450))
        skibidi_image_tk = ImageTk.PhotoImage(skibidi_image)
    except FileNotFoundError:
        print("L'image 'skibidi.png' est introuvable.")
        sys.exit(1)

    skibidi_label = tk.Label(root, image=skibidi_image_tk)
    skibidi_label.pack(pady=20)

    engine = pyttsx3.init()
    engine.say("Veux-tu me rejoindre ?")
    engine.runAndWait()

    def oui_rejoindre():
        confirmation = messagebox.askyesno("Confirmation", "Êtes-vous sûr ?")
        if confirmation:
            with open("game_save.txt", "w") as save_file:
                save_file.write("Skibidi rejoint\n")
            subprocess.Popen([sys.executable, "assets/jumpscare.py"])
        root.quit()

    def non_rejoindre():
        subprocess.Popen([sys.executable, "assets/jumpscare.py"])
        root.quit()

    yes_button = tk.Button(root, text="Oui", font=("Arial", 16), command=oui_rejoindre)
    yes_button.pack(pady=10)

    no_button = tk.Button(root, text="Non", font=("Arial", 16), command=non_rejoindre)
    no_button.pack(pady=10)

    root.mainloop()

# Lancer le jeu
verifier_sauvegarde()
